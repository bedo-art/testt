from django.db import models
from django.conf import settings


class Announcement(models.Model):
    """One-way feed: teacher posts, students read. No comments in MVP."""
    course = models.ForeignKey('courses.Course', on_delete=models.CASCADE, related_name='announcements')
    posted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content = models.TextField()
    attached_file = models.FileField(upload_to='announcement_files/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Announcement in {self.course.title} ({self.created_at:%Y-%m-%d})"


class Message(models.Model):
    """Simple private messaging — no real-time delivery in MVP (refresh to see new messages)."""
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages')
    receiver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages')
    course = models.ForeignKey('courses.Course', on_delete=models.SET_NULL, null=True, blank=True, related_name='messages')
    content = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)
    read_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.sender.username} -> {self.receiver.username}"


class Notification(models.Model):
    class NotificationType(models.TextChoices):
        ENROLLMENT_APPROVED = 'enrollment_approved', 'Enrollment Approved'
        ENROLLMENT_REJECTED = 'enrollment_rejected', 'Enrollment Rejected'
        NEW_HOMEWORK = 'new_homework', 'New Homework'
        HOMEWORK_GRADED = 'homework_graded', 'Homework Graded'
        NEW_ANNOUNCEMENT = 'new_announcement', 'New Announcement'
        NEW_MESSAGE = 'new_message', 'New Message'
        CLASS_REMINDER = 'class_reminder', 'Upcoming Class Reminder'
        SCHEDULE_CHANGE = 'schedule_change', 'Schedule Change'

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=30, choices=NotificationType.choices)
    content = models.CharField(max_length=500)
    related_entity_id = models.PositiveIntegerField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.notification_type}"
