from django.db import models


class Course(models.Model):
    class CourseType(models.TextChoices):
        RECURRING = 'recurring', 'Recurring Class'
        ONE_ON_ONE = 'one_on_one', 'One-on-One'

    class Status(models.TextChoices):
        OPEN = 'open', 'Open for Enrollment'
        CLOSED = 'closed', 'Closed'
        ARCHIVED = 'archived', 'Archived'

    teacher = models.ForeignKey('accounts.TeacherProfile', on_delete=models.CASCADE, related_name='courses')
    title = models.CharField(max_length=255)
    subject = models.CharField(max_length=100)
    grade_level = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    course_type = models.CharField(max_length=20, choices=CourseType.choices, default=CourseType.RECURRING)
    price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    max_capacity = models.PositiveIntegerField(null=True, blank=True)

    # Simple recurring schedule representation for MVP, e.g. "Sun,Tue" 17:00-18:30
    schedule_days = models.CharField(max_length=100, blank=True, help_text="e.g. Sunday,Tuesday")
    start_time = models.TimeField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)
    term_start = models.DateField(null=True, blank=True)
    term_end = models.DateField(null=True, blank=True)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.teacher.user.username})"


class Session(models.Model):
    """A single occurrence of a course — either a recurring class meeting or a booked 1-on-1."""

    class Status(models.TextChoices):
        SCHEDULED = 'scheduled', 'Scheduled'
        COMPLETED = 'completed', 'Completed'
        CANCELLED = 'cancelled', 'Cancelled'

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='sessions')
    scheduled_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    meeting_link = models.URLField(blank=True, help_text="External Zoom/Google Meet link")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SCHEDULED)

    def __str__(self):
        return f"{self.course.title} - {self.scheduled_date}"
