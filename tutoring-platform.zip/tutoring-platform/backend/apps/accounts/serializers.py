from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from .models import User, TeacherProfile


class StudentRegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'phone']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            phone=validated_data.get('phone', ''),
            role=User.Role.STUDENT,
        )
        return user


class TeacherRegisterSerializer(serializers.ModelSerializer):
    """
    Registers a User (role=teacher) AND creates the linked TeacherProfile
    in one request, since a teacher without a profile doesn't make sense
    in this system. Note: the account is NOT publicly listed until a
    Platform Admin approves it (see TeacherProfile.is_publicly_listed).
    """
    password = serializers.CharField(write_only=True, validators=[validate_password])
    bio = serializers.CharField(required=False, allow_blank=True)
    subjects = serializers.CharField(required=False, allow_blank=True)
    grade_levels = serializers.CharField(required=False, allow_blank=True)
    experience_years = serializers.IntegerField(required=False, default=0)
    national_id_number = serializers.CharField(required=False, allow_blank=True)
    id_document = serializers.FileField(required=False)
    credential_document = serializers.FileField(required=False)

    class Meta:
        model = User
        fields = [
            'username', 'email', 'password', 'phone',
            'bio', 'subjects', 'grade_levels', 'experience_years',
            'national_id_number', 'id_document', 'credential_document',
        ]

    def create(self, validated_data):
        profile_fields = [
            'bio', 'subjects', 'grade_levels', 'experience_years',
            'national_id_number', 'id_document', 'credential_document',
        ]
        profile_data = {f: validated_data.pop(f, None) for f in profile_fields}

        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            phone=validated_data.get('phone', ''),
            role=User.Role.TEACHER,
        )
        TeacherProfile.objects.create(user=user, **{k: v for k, v in profile_data.items() if v is not None})
        return user


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role', 'phone', 'status', 'language_preference']
        read_only_fields = ['role', 'status']
