from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Custom user model. We extend Django's built-in user instead of using
    it directly so we can add a `role` field and phone number from day one.
    Swapping AUTH_USER_MODEL later is painful, so we start correctly.
    """

    class Role(models.TextChoices):
        STUDENT = 'student', 'Student'
        TEACHER = 'teacher', 'Teacher'
        CENTER_ADMIN = 'center_admin', 'Center Admin'
        PLATFORM_ADMIN = 'platform_admin', 'Platform Admin'

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.STUDENT)
    phone = models.CharField(max_length=20, blank=True)
    language_preference = models.CharField(max_length=5, default='en')  # 'en' or 'ar' later

    class Status(models.TextChoices):
        ACTIVE = 'active', 'Active'
        SUSPENDED = 'suspended', 'Suspended'
        BANNED = 'banned', 'Banned'

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.ACTIVE)

    def __str__(self):
        return f"{self.username} ({self.role})"


class TeacherProfile(models.Model):
    """
    Extra info specific to teachers (independent or under an organization).
    Kept separate from User so Students don't carry unused teacher fields.
    """

    class VerificationStatus(models.TextChoices):
        PENDING = 'pending', 'Pending Review'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='teacher_profile')
    organization = models.ForeignKey(
        'organizations.Organization', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='teachers'
    )
    bio = models.TextField(blank=True)
    subjects = models.CharField(max_length=500, blank=True, help_text="Comma-separated for MVP")
    grade_levels = models.CharField(max_length=500, blank=True, help_text="Comma-separated for MVP")
    experience_years = models.PositiveIntegerField(default=0)

    national_id_number = models.CharField(max_length=50, blank=True)
    id_document = models.FileField(upload_to='verification_docs/ids/', blank=True, null=True)
    credential_document = models.FileField(upload_to='verification_docs/credentials/', blank=True, null=True)

    verification_status = models.CharField(
        max_length=20, choices=VerificationStatus.choices, default=VerificationStatus.PENDING
    )
    is_publicly_listed = models.BooleanField(default=False)  # only True once approved
    badges = models.CharField(max_length=300, blank=True, help_text="Comma-separated badge names")

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"TeacherProfile: {self.user.username}"
