from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView

from .models import User
from .serializers import StudentRegisterSerializer, TeacherRegisterSerializer, UserSerializer


class StudentRegisterView(generics.CreateAPIView):
    """POST here to create a new Student account. Publicly accessible."""
    queryset = User.objects.all()
    serializer_class = StudentRegisterSerializer
    permission_classes = [permissions.AllowAny]


class TeacherRegisterView(generics.CreateAPIView):
    """
    POST here to register as a Teacher (independent tutor).
    Account is created immediately but NOT publicly visible/listed until
    a Platform Admin reviews and approves the verification documents
    via the Django admin panel (or a future dedicated admin API).
    """
    queryset = User.objects.all()
    serializer_class = TeacherRegisterSerializer
    permission_classes = [permissions.AllowAny]


class MeView(APIView):
    """Returns the currently logged-in user's own profile info."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


class LoginView(TokenObtainPairView):
    """
    POST {username, password} here to receive {access, refresh} JWT tokens.
    Use the access token as: Authorization: Bearer <access>
    """
    pass
