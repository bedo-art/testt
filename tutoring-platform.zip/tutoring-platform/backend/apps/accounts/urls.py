from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import StudentRegisterView, TeacherRegisterView, MeView, LoginView

urlpatterns = [
    path('register/student/', StudentRegisterView.as_view(), name='register-student'),
    path('register/teacher/', TeacherRegisterView.as_view(), name='register-teacher'),
    path('login/', LoginView.as_view(), name='login'),
    path('login/refresh/', TokenRefreshView.as_view(), name='login-refresh'),
    path('me/', MeView.as_view(), name='me'),
]
