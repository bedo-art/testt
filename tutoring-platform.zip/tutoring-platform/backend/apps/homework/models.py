from django.db import models
from django.conf import settings


class Homework(models.Model):
    class SubmissionType(models.TextChoices):
        FILE = 'file', 'File Upload'
        TEXT = 'text', 'Text Response'
        BOTH = 'both', 'Both'

    course = models.ForeignKey('courses.Course', on_delete=models.CASCADE, related_name='homework_items')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    submission_type = models.CharField(max_length=10, choices=SubmissionType.choices, default=SubmissionType.BOTH)
    due_date = models.DateTimeField(null=True, blank=True)
    allow_late_submissions = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.course.title})"


class HomeworkSubmission(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = 'submitted', 'Submitted'
        RETURNED = 'returned', 'Returned for Correction'
        GRADED = 'graded', 'Graded'

    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name='submissions')
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='homework_submissions')
    submitted_file = models.FileField(upload_to='homework_submissions/', blank=True, null=True)
    text_response = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    is_late = models.BooleanField(default=False)
    grade = models.CharField(max_length=20, blank=True)
    feedback = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)

    class Meta:
        unique_together = ('homework', 'student')

    def save(self, *args, **kwargs):
        # Auto-flag late submissions based on the homework's due date.
        if self.homework.due_date and not self.pk:
            from django.utils import timezone
            self.is_late = timezone.now() > self.homework.due_date
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.student.username} - {self.homework.title}"
