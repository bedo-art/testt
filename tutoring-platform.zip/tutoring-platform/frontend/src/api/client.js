import axios from 'axios'

// During local dev, the Django backend runs on port 8000 by default.
const API_BASE_URL = 'http://localhost:8000/api'

const client = axios.create({
  baseURL: API_BASE_URL,
})

// Attach the JWT access token (if we have one) to every outgoing request.
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default client
