import { useAuth } from '../context/AuthContext.jsx'

export default function Dashboard() {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="max-w-4xl mx-auto mt-12 px-6">
      <h1 className="text-2xl font-bold mb-2">Welcome, {user.username} 👋</h1>
      <p className="text-gray-500 mb-8">
        Logged in as: <span className="font-medium capitalize">{user.role.replace('_', ' ')}</span>
      </p>

      {user.role === 'student' && <StudentDashboard />}
      {user.role === 'teacher' && <TeacherDashboard />}
      {user.role === 'center_admin' && <CenterAdminDashboard />}
      {user.role === 'platform_admin' && <PlatformAdminDashboard />}
    </div>
  )
}

// Each of these is a placeholder — this is where Phase 2+ features
// (courses, enrollments, homework, etc.) will be built out.

function StudentDashboard() {
  return (
    <Card title="My Courses">
      You haven't enrolled in any courses yet. Browse available teachers to get started.
    </Card>
  )
}

function TeacherDashboard() {
  return (
    <Card title="My Classes">
      You haven't created any classes yet. This is where you'll manage your courses,
      enrollment requests, homework, and attendance.
    </Card>
  )
}

function CenterAdminDashboard() {
  return (
    <Card title="Organization Overview">
      Manage your teachers, view center-wide classes, and monitor students here.
    </Card>
  )
}

function PlatformAdminDashboard() {
  return (
    <Card title="Platform Admin">
      Use the full Django admin panel at <code className="bg-gray-100 px-1 rounded">/admin/</code> to
      approve teachers, manage subscriptions, and moderate content.
    </Card>
  )
}

function Card({ title, children }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <p className="text-gray-500 text-sm">{children}</p>
    </div>
  )
}
